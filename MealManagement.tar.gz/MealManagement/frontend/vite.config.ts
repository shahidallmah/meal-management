import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// During development /api is proxied to the .NET API (launchSettings: http://localhost:5080).
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: { '/api': { target: 'http://localhost:5080', changeOrigin: true } },
  },
});
